﻿#nullable enable
using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PowerSimBuilder.Physics;

/// <summary>
/// Installs a catalog FMU as user_physics_models/{name}/source/{name}.fmu + model.yaml.
/// Download is delegated to the existing FmuDownloader.
/// </summary>
public sealed class FmuCatalogInstaller
{
    private readonly FmuDownloader _downloader;

    public FmuCatalogInstaller(FmuDownloader downloader) => _downloader = downloader;

    public async Task<bool> InstallAsync(
        FmuModel model, string outputDir, Action<string>? log = null, CancellationToken ct = default)
    {
        try
        {
            var safe = FmuCatalogMetadata.SanitizeName(model.Name);
            var modelDir = Path.Combine(outputDir, safe);
            var fmuPath = Path.Combine(modelDir, "source", safe + ".fmu");

            log?.Invoke($"Downloading {model.Name}...");
            var result = await _downloader.DownloadAsync(model.DownloadUrl, fmuPath, null, ct);
            if (!result.Success)
            {
                log?.Invoke($"  [ERROR] {result.ErrorMessage}");
                return false;
            }
            log?.Invoke($"  Downloaded: {result.BytesDownloaded / 1024} KB");

            log?.Invoke("  Parsing modelDescription.xml...");
            var meta = FmuCatalogMetadata.Parse(fmuPath);
            model.FmiVersion = meta.FmiVersion;
            model.FmiType = meta.FmiType;

            var yaml = FmuCatalogMetadata.GenerateModelYaml(meta, $"source/{safe}.fmu");
            File.WriteAllText(Path.Combine(modelDir, "model.yaml"), yaml, new UTF8Encoding(false));

            log?.Invoke($"  model.yaml: {meta.Inputs.Count} in, {meta.Outputs.Count} out, {meta.Parameters.Count} params");
            log?.Invoke($"  Installed to: {modelDir}");
            if (meta.FmiType != "CoSimulation")
                log?.Invoke($"  [WARN] {meta.FmiType} - not CoSimulation");
            return true;
        }
        catch (Exception ex)
        {
            log?.Invoke($"  [ERROR] {ex.Message}");
            return false;
        }
    }
}