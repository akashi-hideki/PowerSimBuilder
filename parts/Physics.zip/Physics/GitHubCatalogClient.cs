﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;

namespace PowerSimBuilder.Physics
{
    /// <summary>
    /// Browses FMU directories using GitHub Contents API (no tree truncation).
    /// Port of Python's GitHubCatalogClient from fmu_catalog_browser.py.
    /// </summary>
    public class GitHubCatalogClient
    {
        private readonly HttpClient _httpClient;
        private readonly string _apiKey;
        private string _branch;

        public GitHubCatalogClient(string apiKey = "")
        {
            _apiKey = apiKey;
            
            var handler = new HttpClientHandler();
            
            // プロキシ設定（AppSettingsから読み込み）
            var proxyUrl = AppSettings.GitHubProxyUrl;
            if (!string.IsNullOrEmpty(proxyUrl))
            {
                handler.Proxy = new WebProxy(proxyUrl);
                handler.UseProxy = true;
            }
            
            _httpClient = new HttpClient(handler)
            {
                Timeout = TimeSpan.FromSeconds(60)
            };
            
            ConfigureHeaders();
        }

        private void ConfigureHeaders()
        {
            _httpClient.DefaultRequestHeaders.Clear();
            _httpClient.DefaultRequestHeaders.Add("Accept", "application/vnd.github.v3+json");
            _httpClient.DefaultRequestHeaders.Add("User-Agent", "PowerSimBuilder-FMU-Browser");
            
            if (!string.IsNullOrEmpty(_apiKey))
            {
                _httpClient.DefaultRequestHeaders.Add("Authorization", $"token {_apiKey}");
            }
        }

        private async Task<JsonElement> ApiGetAsync(string url)
        {
            try
            {
                var response = await _httpClient.GetAsync(url);
                
                if (response.StatusCode == HttpStatusCode.Forbidden)
                {
                    throw new InvalidOperationException(
                        "GitHub API rate limit exceeded. Set an API key (github.com/settings/tokens).");
                }
                
                if (!response.IsSuccessStatusCode)
                {
                    throw new InvalidOperationException(
                        $"GitHub API error: {(int)response.StatusCode} {response.ReasonPhrase}");
                }
                
                var content = await response.Content.ReadAsStringAsync();
                return JsonDocument.Parse(content).RootElement;
            }
            catch (HttpRequestException ex)
            {
                throw new InvalidOperationException($"Network error: {ex.Message}");
            }
        }

        private async Task<string> GetBranchAsync(string repo)
        {
            if (!string.IsNullOrEmpty(_branch))
                return _branch;
            
            var data = await ApiGetAsync($"https://api.github.com/repos/{repo}");
            _branch = data.GetProperty("default_branch").GetString() ?? "main";
            return _branch;
        }

        private async Task<JsonElement> GetContentsAsync(string repo, string path)
        {
            var branch = await GetBranchAsync(repo);
            return await ApiGetAsync($"https://api.github.com/repos/{repo}/contents/{path}?ref={branch}");
        }

        /// <summary>
        /// Browse fmus/{ver}/{type}/{platform}/ and list all models.
        /// </summary>
        public async Task<List<FmuModel>> FetchAsync(
            string repo,
            string versionFilter,
            string typeFilter,
            string platformFilter,
            Action<string> logAction = null)
        {
            if (string.IsNullOrEmpty(versionFilter) || 
                string.IsNullOrEmpty(typeFilter) || 
                string.IsNullOrEmpty(platformFilter))
            {
                throw new InvalidOperationException("Filters required (version/type/platform)");
            }

            var basePath = $"fmus/{versionFilter}/{typeFilter}/{platformFilter}";
            var branch = await GetBranchAsync(repo);
            
            logAction?.Invoke($"Fetching: {repo} / {basePath} (branch: {branch})");

            // Step 1: Get tool directories
            JsonElement tools;
            try
            {
                tools = await GetContentsAsync(repo, basePath);
            }
            catch (InvalidOperationException ex)
            {
                if (ex.Message.Contains("404"))
                {
                    throw new InvalidOperationException(
                        $"Path not found: {basePath}\nCheck if the repo has this FMI version/type/platform combination.");
                }
                throw;
            }

            var toolDirs = new List<JsonElement>();
            foreach (var t in tools.EnumerateArray())
            {
                if (t.GetProperty("type").GetString() == "dir")
                {
                    toolDirs.Add(t);
                }
            }
            
            logAction?.Invoke($"Found {toolDirs.Count} tool directories");

            var models = new List<FmuModel>();
            int toolIndex = 0;
            
            foreach (var tool in toolDirs)
            {
                toolIndex++;
                var toolName = tool.GetProperty("name").GetString();
                logAction?.Invoke($"  [{toolIndex}/{toolDirs.Count}] {toolName}...");

                try
                {
                    var modelDirs = await GetContentsAsync(repo, $"{basePath}/{toolName}");
                    
                    foreach (var md in modelDirs.EnumerateArray())
                    {
                        if (md.GetProperty("type").GetString() != "dir")
                            continue;
                        
                        var modelName = md.GetProperty("name").GetString();
                        var fmuPath = $"{basePath}/{toolName}/{modelName}/files/model.fmu";
                        var downloadUrl = $"https://raw.githubusercontent.com/{repo}/{branch}/{fmuPath}";
                        
                        models.Add(new FmuModel
                        {
                            Name = modelName,
                            DownloadUrl = downloadUrl,
                            FmiVersion = versionFilter,
                            FmiType = typeFilter == "cs" ? "CoSimulation" : "ModelExchange",
                            Platform = platformFilter,
                            SizeBytes = 0,
                            Source = $"{repo.Split('/')[^1]} / {toolName}"
                        });
                    }
                }
                catch (Exception ex)
                {
                    logAction?.Invoke($"    [WARN] {ex.Message}");
                }
            }

            // Deduplicate
            var seen = new HashSet<string>();
            var unique = new List<FmuModel>();
            
            foreach (var m in models)
            {
                var key = $"{m.Name}_{m.FmiVersion}_{m.FmiType}_{m.Platform}";
                if (seen.Add(key))
                {
                    unique.Add(m);
                }
            }

            return unique;
        }
    }
}